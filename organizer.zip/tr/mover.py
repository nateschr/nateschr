import os, matplotlib
import shutil

rootdir = 'C:/Users/chemist/Scripts/tr/library/'
kc_dir = 'C:/Users/chemist/Scripts/tr/kc/'
hh_dir = 'C:/Users/chemist/Scripts/tr/hh/'
rd_dir = 'C:/Users/chemist/Scripts/tr/rd/'
tbd_dir = 'C:/Users/chemist/Scripts/tr/tbd/'

for subdir, dirs, files in os.walk(rootdir):
    for file in files:
        
        if 'kc' in file:
            print(file)
            shutil.move(str(subdir) + str('/') + str(file), str(kc_dir) + str(file))
            
        elif 'rd' in file:
            print(file)
            shutil.move(str(subdir) + str('/') + str(file), str(rd_dir) + str(file))
            
        elif 'hh' in file:
            print(file)
            shutil.move(str(subdir) + str('/') + str(file), str(hh_dir) + str(file))
        
        else:
            shutil.move(str(subdir) + str('/') + str(file), str(tbd_dir) + str(file))
    
